/* =======================================================
   AUDIO API (Shared)
   ======================================================= */
let audioCtx = null, musicPlaying = false, musicNodes = [];
const notes = { C4:261.63, D4:293.66, E4:329.63, F4:349.23, G4:392, A4:440, B4:493.88, C5:523.25, D5:587.33, E5:659.25, G5:783.99 };
const melody = [
  ['E5',0.25],['D5',0.25],['C5',0.25],['D5',0.25],['E5',0.25],['E5',0.25],['E5',0.5],
  ['D5',0.25],['D5',0.25],['D5',0.5],['E5',0.25],['G5',0.25],['G5',0.5],
  ['E5',0.25],['D5',0.25],['C5',0.25],['D5',0.25],['E5',0.25],['E5',0.25],['E5',0.25],['E5',0.25],
  ['D5',0.25],['D5',0.25],['E5',0.25],['D5',0.25],['C5',1.0]
];

function playMelody() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const ctx = audioCtx;
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.18, ctx.currentTime);
  masterGain.connect(ctx.destination);
  musicNodes = [masterGain];

  let t = ctx.currentTime + 0.05;
  const totalDur = melody.reduce((s,[,d]) => s+d, 0);

  function scheduleLoop(offset) {
    melody.forEach(([note, dur]) => {
      const osc = ctx.createOscillator(); const g = ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = notes[note];
      g.gain.setValueAtTime(0, offset);
      g.gain.linearRampToValueAtTime(0.5, offset + 0.02);
      g.gain.linearRampToValueAtTime(0.3, offset + dur * 0.7);
      g.gain.linearRampToValueAtTime(0, offset + dur);
      osc.connect(g); g.connect(masterGain);
      osc.start(offset); osc.stop(offset + dur + 0.01);
      musicNodes.push(osc, g); offset += dur;
    });
    if (musicPlaying) setTimeout(() => scheduleLoop(ctx.currentTime + 0.05), (totalDur - 0.3) * 1000);
  }
  scheduleLoop(t);
}

function stopMusic() { musicNodes.forEach(n => { try { n.disconnect(); } catch(e){} }); musicNodes = []; }

document.getElementById('musicBtn').addEventListener('click', () => {
  const btn = document.getElementById('musicBtn');
  if (!musicPlaying) {
    musicPlaying = true; btn.textContent = '🎶'; btn.classList.add('playing'); playMelody();
  } else {
    musicPlaying = false; btn.textContent = '🎵'; btn.classList.remove('playing'); stopMusic();
  }
});

function playPop(type = 'yes') {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = audioCtx; const osc = ctx.createOscillator(); const g = ctx.createGain();
    osc.connect(g); g.connect(ctx.destination);
    if (type === 'yes') {
      osc.type = 'sine'; osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
      g.gain.setValueAtTime(0.3, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      osc.start(); osc.stop(ctx.currentTime + 0.3);
    } else {
      osc.type = 'sawtooth'; osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.2);
      g.gain.setValueAtTime(0.15, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.start(); osc.stop(ctx.currentTime + 0.25);
    }
  } catch(e){}
}

function playHeartSound() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = audioCtx;
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator(); const g = ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = freq;
      g.gain.setValueAtTime(0, ctx.currentTime + i * 0.1);
      g.gain.linearRampToValueAtTime(0.25, ctx.currentTime + i * 0.1 + 0.05);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.1 + 0.4);
      osc.connect(g); g.connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.1); osc.stop(ctx.currentTime + i * 0.1 + 0.5);
    });
  } catch(e){}
}

/* =======================================================
   SCREEN 1 LOGIC (The Question Game)
   ======================================================= */
(function initScreen1Particles() {
  const cont = document.getElementById('particles');
  const items = ['🌸','💕','✨','🌷','💖','⭐','🍓','🌺','💗','🎀'];
  for (let i = 0; i < 28; i++) {
    const el = document.createElement('div'); el.className = 'particle';
    el.textContent = items[Math.floor(Math.random() * items.length)];
    el.style.left = Math.random() * 100 + 'vw'; el.style.fontSize = (0.8 + Math.random() * 1.1) + 'rem';
    el.style.animationDuration = (7 + Math.random() * 11) + 's'; el.style.animationDelay = (Math.random() * 14) + 's';
    cont.appendChild(el);
  }
})();

const SCENES = [
  { gif: "https://media.tenor.com/76BaX0eo304AAAAj/kitty-kitty-heart.gif", noText: "ไม่รัก 😢", question: "เทอรักเค้าไหม? 💖" },
  { gif: "https://media1.tenor.com/m/wVAjxnPa81IAAAAd/cat-cat-gif.gif", noText: "ยังไม่แน่ใจ 🙈", question: "แน่ใจนะ? แมวก็ยังเศร้าเลย 😿" },
  { gif: "https://media1.tenor.com/m/f6ts3WWJa-8AAAAC/funny-cats-funny.gif", noText: "ขอคิดก่อน 🤔", question: "แมวนี้ก็ยังงงเลย... 😅" },
  { gif: "https://media1.tenor.com/m/kEZzd8WrRpAAAAAC/peach-peach-and-goma.gif", noText: "อืม... 😶", question: "พีชกับโกมายังรักกันเลยนะ 🍑" },
  { gif: "https://media.tenor.com/C35t4Pf5GlgAAAAi/peach-and-goma-cute.gif", noText: "ไม่ได้ไม่รัก แค่... 🥺", question: "โกมาก็ยังน้อยใจเลยค่ะ 🥺" },
  { gif: "https://media1.tenor.com/m/troWhJKIjZsAAAAC/hey-cat.gif", noText: "...", question: "แมวบอกว่า... กดเลิฟเถอะนะ! 🐱" }
];
const YES_GIF  = "https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif";
const LOVE_GIF = "https://media1.tenor.com/m/qR1sGRNmfqsAAAAC/besito-catlove.gif";

let noCount = 0; let yesBtnSize = 1;

function swapGif(src) {
  const img = document.getElementById('gif'); img.classList.add('fade-out');
  setTimeout(() => {
    img.src = src; img.onload = () => img.classList.remove('fade-out');
    img.onerror = () => img.classList.remove('fade-out'); img.classList.remove('fade-out');
  }, 300);
}

function burstHeartsScreen1(x, y, count = 12) {
  const emojis = ['💖','❤️','🌹','💛','✨','💝','🌸','🎀','💗'];
  for (let i = 0; i < count; i++) {
    const h = document.createElement('div'); h.className = 'burst-heart';
    h.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    const angle = (Math.random() * Math.PI * 2); const dist = 60 + Math.random() * 140;
    h.style.left = x + 'px'; h.style.top = y + 'px';
    h.style.setProperty('--dx', Math.cos(angle) * dist + 'px'); h.style.setProperty('--dy', Math.sin(angle) * dist + 'px');
    h.style.fontSize = (1 + Math.random() * 1.2) + 'rem';
    document.body.appendChild(h); setTimeout(() => h.remove(), 950);
  }
}

function renderDots(current, total) {
  const dotsEl = document.getElementById('dots'); dotsEl.innerHTML = '';
  for (let i = 0; i < total; i++) {
    const d = document.createElement('div'); d.className = 'dot' + (i < current ? ' active' : '');
    dotsEl.appendChild(d);
  }
}

function renderMainButtons() {
  const cont = document.getElementById('q-btnContainer');
  cont.innerHTML = `
    <button class="q-btn q-yes" id="yesBtn">ใช่ รักเลย 💕</button>
    <button class="q-btn q-no"  id="noBtn">${SCENES[noCount].noText}</button>
  `;
  const yesBtn = document.getElementById('yesBtn');
  yesBtn.style.fontSize = (1 + yesBtnSize * 0.12) + 'rem';
  yesBtn.style.padding  = `${12 + yesBtnSize * 1.5}px ${28 + yesBtnSize * 3}px`;
  document.getElementById('yesBtn').addEventListener('click', yesClick);
  document.getElementById('noBtn').addEventListener('click', noClick);
}

function startQuestionGame() {
  noCount = 0; yesBtnSize = 1; const scene = SCENES[0];
  document.getElementById('question').textContent = scene.question;
  swapGif(scene.gif); renderDots(0, SCENES.length); renderMainButtons();
}

function proceedToGraduation() {
  const s1 = document.getElementById('screen1');
  const s2 = document.getElementById('screen2');
  const btn = document.getElementById('musicBtn');
  
  s1.style.opacity = '0';
    s1.style.transform = 'translateY(-24px) scale(0.96)';
  
  setTimeout(() => {
    s1.style.display = 'none';
    s2.style.display = 'flex';

    s2.style.opacity = '0';
    s2.style.transform = 'translateY(20px) scale(0.96)';
    btn.classList.add('dark-music-btn');
    setTimeout(() => {
      s2.style.opacity = '1';
      s2.style.transform = 'translateY(0) scale(1)';
    }, 50);
  }, 800);
}

function yesClick(e) {
  playPop('yes'); playHeartSound(); burstHeartsScreen1(e.clientX, e.clientY, 18);
  swapGif(YES_GIF); document.getElementById('question').innerHTML = `<span>เย่!! เค้าก็รักเทอเหมือนกัน 💗</span>`;
  renderDots(SCENES.length, SCENES.length);
  document.getElementById('q-btnContainer').innerHTML = '';
  setTimeout(proceedToGraduation, 2000);
}

function loveClick(e) {
  playHeartSound(); burstHeartsScreen1(e.clientX, e.clientY, 26);
  swapGif(LOVE_GIF);
  document.getElementById('question').innerHTML = `<div class="msg-box">รักเหมือนกันนนน 💞<br>หัวใจจะแตกอยู่แล้ว!<br><small>เค้ารอให้รู้อยู่นานมากเลยนะ 🥺</small></div>`;
  document.getElementById('q-btnContainer').innerHTML = '';
  setTimeout(proceedToGraduation, 2000);
}

function noClick(e) {
  playPop('no');
  const card = document.getElementById('q-card');
  card.classList.remove('wiggle'); void card.offsetWidth; card.classList.add('wiggle');
  setTimeout(() => card.classList.remove('wiggle'), 400);
  
  noCount++; yesBtnSize++; renderDots(noCount, SCENES.length);
  const sceneIdx = Math.min(noCount, SCENES.length - 1); const scene = SCENES[sceneIdx];
  document.getElementById('question').textContent = scene.question; swapGif(scene.gif);

  if (noCount >= SCENES.length - 1) {
    document.getElementById('q-btnContainer').innerHTML = `<button class="q-btn q-love" id="loveBtn">💘 LOVE!</button>`;
    document.getElementById('loveBtn').addEventListener('click', loveClick);
    renderDots(SCENES.length, SCENES.length);
  } else {
    renderMainButtons();
    const noBtn = document.getElementById('noBtn'); if (noBtn) noBtn.textContent = SCENES[sceneIdx].noText;
  }
}

// Init Screen 1
startQuestionGame();

/* =======================================================
   SCREEN 2 → 3 TRANSITION
   ======================================================= */
document.getElementById('giftBtn').addEventListener('click', () => {
  const s2 = document.getElementById('screen2');
  const s3 = document.getElementById('screen3');

  s2.style.opacity = '0';
  s2.style.transform = 'scale(0.98) translateY(-12px)';

  setTimeout(() => {
    s2.style.display = 'none';
    s3.style.display = 'flex';
    s3.style.opacity = '0';

    setTimeout(() => {
      s3.style.opacity = '1';
    }, 50);
  }, 300);
});

/* =======================================================
   SCREEN 3 LOGIC (Love Letter Envelope)
   ======================================================= */
(function initScreen3() {
  // Create floating hearts
  const heartsCont = document.getElementById('letterHearts');
  if (heartsCont) {
    const hearts = ['💖','💕','💗','💘','🌹','✨','🌸','💝'];
    for (let i = 0; i < 15; i++) {
      const el = document.createElement('div');
      el.className = 'floating-heart';
      el.textContent = hearts[Math.floor(Math.random() * hearts.length)];
      el.style.left = Math.random() * 100 + 'vw';
      el.style.fontSize = (0.8 + Math.random() * 0.8) + 'rem';
      el.style.animationDuration = (8 + Math.random() * 10) + 's';
      el.style.animationDelay = (Math.random() * 12) + 's';
      heartsCont.appendChild(el);
    }
  }

  // Envelope click to open
  const envelopeBody = document.getElementById('envelopeBody');
  if (envelopeBody) {
    envelopeBody.addEventListener('click', () => {
      envelopeBody.classList.toggle('opened');
      if (envelopeBody.classList.contains('opened')) {
        playHeartSound();
      }
    });
  }

  // Back button
  const backBtn = document.getElementById('letterBackBtn');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      const s3 = document.getElementById('screen3');
      const s2 = document.getElementById('screen2');
      
      s3.style.opacity = '0';
      setTimeout(() => {
        s3.style.display = 'none';
        s2.style.display = 'flex';
        setTimeout(() => {
          s2.style.opacity = '1';
          s2.style.transform = 'translateY(0) scale(1)';
        }, 50);
      }, 400);
    });
  }
})();
